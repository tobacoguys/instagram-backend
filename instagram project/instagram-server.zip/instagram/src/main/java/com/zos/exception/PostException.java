package com.zos.exception;

public class PostException extends Exception {
	
	public PostException() {
		// TODO Auto-generated constructor stub
	}
	
	public PostException(String message) {
		super(message);
	}

}
