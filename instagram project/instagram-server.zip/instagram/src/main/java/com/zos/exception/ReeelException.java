package com.zos.exception;

public class ReeelException extends Exception {
	
	public ReeelException(String message) {
		super(message);
		
	}

}
