package com.zos.security;

public class JwtTokenClaims {
	
	private String username;
	
	public String getUsername() {
		return this.username;
	}
	
	public void setUsername(String username) {
		this.username=username;
	}
	
}
